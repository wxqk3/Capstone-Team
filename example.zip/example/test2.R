
# Return a Shiny app object
library(shiny)
n  <-100

ui <- bootstrapPage(
  div(
    numericInput('n', 'Number of obs', n),
  plotOutput('plot')
  ),
  
  div(
  
    # to include a separate HTML file.
    includeHTML("static.html")
  )
)

server <- function(input, output) {
  output$plot <- renderPlot({
    hist(runif(input$n))
  })
}

shinyApp(ui = ui, server = server)
